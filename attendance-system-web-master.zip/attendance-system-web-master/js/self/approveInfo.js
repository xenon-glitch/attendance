$(function() {
	$.ajax({
		type: "post",
		url: "", // 请求地址
		async: false,
		dataType: "json",
		data: { // 发送的数据asdasd

		},
		success: function(message) { //成功后执行的函数  message为后台返回的数据集 json格式

		},
		error: function() { //错误后执行的函数
			
		}
	});
});